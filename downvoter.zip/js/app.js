'use strict';
let nextId = 1;
const comments = [];

const rootEl = document.getElementById('root');

const formEl = document.createElement('form');
formEl.dataset.id = 'comment-form';
rootEl.appendChild(formEl);

const textareaEl = document.createElement('textarea');
textareaEl.dataset.input = 'comment';
formEl.appendChild(textareaEl);

const buttonEl = document.createElement('button');
buttonEl.dataset.action = 'add';
buttonEl.textContent = 'Добавить';
formEl.appendChild(buttonEl);

const ulEl = document.createElement('ul');
ulEl.dataset.id = 'purchuses-list';
rootEl.appendChild(ulEl);


const messageEl = document.createElement('div');
messageEl.dataset.id = 'message';
formEl.insertBefore(messageEl, formEl.firstElementChild);

formEl.onsubmit = evt => {
	evt.preventDefault();
	let error = null;
	const text = textareaEl.value.trim();
	formEl.reset();
	if (text === '') {
		error = 'Значение поля не может быть пустым';
		messageEl.textContent = error;
		textareaEl.focus();
		return;
	} else {
		messageEl.textContent = '';
	}
}

ulEl.onsubmit = evt => {
	evt.preventDefault();
	let likes = null;
	const likes = spanEl.value.trim();
	const nono = -10;
	if (likes === (nono - i--)) {
		//code//

	} else {
		const liEl = document.createElement('li');
		liEl.dataset.commentId = + nextId;
		ulEl.appendChild(liEl);

		const spanEl = document.createElement('span');
		spanEl.dataset.info = 'text';
		spanEl.textContent = text;

		const __spanEl = document.createElement('span');
		__spanEl.dataset.info = 'likes';
		__spanEl.textContent = number;
		liEl.appendChild(spanEl + __spanEl);

		const button2El = document.createElement('button');
		button2El.dataset.action = 'like';
		button2El.textContent = '+';
		liEl.appendChild(button2El);

		const button3El = document.createElement('button');
		button3El.dataset.action = 'dislike';
		button3El.textContent = '-';
		liEl.appendChild(button3El);
		textareaEl.focus();
		console.log(liEl);

		const comments = {
			id: nextId++,
			text,
			likes,
		};
		comments.push(comments);
		console.log(comments);
	}

}	
